package Controller;

import BaseDeDatos.ProductoDAO;
import ClasesModelos.Productos;

import java.util.List;

public class ProductoController {
    private ProductoDAO productoDAO;

    public boolean agregarProducto(Productos producto) {
        productoDAO = new ProductoDAO();
        return productoDAO.agregarProducto(producto);
    }

    public List<Productos> obtenerProductos() {
        productoDAO = new ProductoDAO();
        return productoDAO.mostrarProductos();
    }

    public List<Productos> filtrarProductosCategoria(String nombreCategoria) {
        productoDAO = new ProductoDAO();
        return productoDAO.obtenerProductosID(nombreCategoria);
    }

    public Productos buscarProductos(Productos producto) {
        productoDAO = new ProductoDAO();
        return productoDAO.buscarProducto(producto);
    }

    public boolean editarProducto(Productos producto) {
        productoDAO = new ProductoDAO();
        return productoDAO.editarProducto(producto);
    }

    public boolean inhabilitarProducto(Productos producto) {
        productoDAO = new ProductoDAO();
        return productoDAO.inhabilitarProducto(producto);
    }

    public boolean habilitarProducto(Productos producto) {
        productoDAO = new ProductoDAO();
        return productoDAO.habilitarProducto(producto);
    }

    public boolean editarStockProducto(Productos producto) {
        productoDAO = new ProductoDAO();
        return productoDAO.editarStockProducto(producto);
    }

}
